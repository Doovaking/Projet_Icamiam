from .cart import Cart

#Crée le contexte processor pour que ca marche sur toutes les pages
def cart(request):
    return{'cart': Cart(request)}

